import React from 'react'

export default function SMSDetails({ message }) {
  if (!message) {
    return (
      <div className="bg-white rounded-lg border border-black/5 border-dashed p-6 text-center text-ink/40 text-sm">
        Select a message from the table to see its details.
      </div>
    )
  }

  const topTerms = [...message.termFrequency.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8)
  const uniqueTerms = message.termFrequency.size

  return (
    <div className="bg-white rounded-lg border border-black/5 p-6 min-w-0">
      <p className="text-xs uppercase tracking-wide text-ink/40 mb-2">Actual Label (Dataset)</p>
      <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium mb-4 ${message.label === 'spam' ? 'bg-clay2 text-white' : 'bg-teal4 text-white'}`}>
        {message.label === 'spam' ? 'Spam' : 'Normal'}
      </span>

      <p className="text-xs uppercase tracking-wide text-ink/40 mb-1">Message Content</p>
      <div className="bg-paper rounded-md p-3 text-sm text-ink/80 mb-4 max-h-40 overflow-y-auto break-words">
        {message.message}
      </div>

      <div className="space-y-2 mb-4">
        {[
          ['Message ID', `#${message.id}`],
          ['Word Count', message.wordCount],
          ['Character Count', message.charCount],
          ['URL Count', message.urlCount],
          ['Number Count', message.numberCount],
          ['Special Character Count', message.specialCharCount],
          ['Unique Terms', uniqueTerms],
          ['Average Word Length', message.avgWordLength.toFixed(1)],
        ].map(([label, value]) => (
          <div key={label} className="flex justify-between text-sm py-1.5 border-b border-black/5 last:border-0">
            <span className="text-ink/50">{label}</span>
            <span className="text-ink font-medium">{value}</span>
          </div>
        ))}
      </div>

      {topTerms.length > 0 && (
        <div>
          <p className="text-xs uppercase tracking-wide text-ink/40 mb-2">Most Frequent Terms</p>
          <div className="flex flex-wrap gap-1.5">
            {topTerms.map(([term, count]) => (
              <span key={term} className="text-xs px-2 py-1 rounded-full bg-black/5 text-ink/70">{term} ({count})</span>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

/** Word-frequency map per class from tokenized training messages. */
export function wordFrequencyByClass(tokenizedMessages) {
  const freq = { spam: new Map(), ham: new Map() }
  tokenizedMessages.forEach((e) => {
    e.tokens.forEach((t) => {
      freq[e.label].set(t, (freq[e.label].get(t) || 0) + 1)
    })
  })
  return freq
}

export function topWordsFromFrequency(freqMap, n = 15) {
  return [...freqMap.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, n)
    .map(([term, count]) => ({ term, count }))
}

/** Terms most associated with each class, from the trained model itself (not raw counts). */
export function modelTopTerms(model, vocabModel, n = 15) {
  const { vocabulary } = vocabModel

  if (model.type === 'naive-bayes') {
    const scored = vocabulary.map((term, i) => ({
      term,
      score: model.logLikelihood.spam[i] - model.logLikelihood.ham[i],
    }))
    return {
      spamTerms: [...scored].sort((a, b) => b.score - a.score).slice(0, n),
      hamTerms: [...scored].sort((a, b) => a.score - b.score).slice(0, n),
    }
  }

  // logistic-regression: positive weight -> pushes toward spam, negative -> toward ham
  const scored = model.topWeights.map((w) => ({ term: vocabulary[w.index], score: w.weight }))
  return {
    spamTerms: scored.filter((s) => s.score > 0).sort((a, b) => b.score - a.score).slice(0, n),
    hamTerms: scored.filter((s) => s.score < 0).sort((a, b) => a.score - b.score).slice(0, n),
  }
}

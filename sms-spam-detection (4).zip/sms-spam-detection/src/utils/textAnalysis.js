const URL_REGEX = /(https?:\/\/|www\.)[^\s]+/gi
const NUMBER_REGEX = /\d+/g
const SPECIAL_CHAR_REGEX = /[^a-zA-Z0-9\s]/g
const SENTENCE_SPLIT_REGEX = /[.!?]+(\s|$)/g

/** Computes descriptive text statistics from the raw (unmodified) message text. */
export function analyzeText(rawText) {
  const text = rawText || ''
  const words = text.trim().length ? text.trim().split(/\s+/) : []
  const urls = text.match(URL_REGEX) || []
  const numbers = text.match(NUMBER_REGEX) || []
  const specialChars = text.match(SPECIAL_CHAR_REGEX) || []
  const uppercaseChars = (text.match(/[A-Z]/g) || []).length
  const sentences = text.trim().length ? text.split(SENTENCE_SPLIT_REGEX).filter((s) => s.trim().length > 0) : []

  const avgWordLength = words.length
    ? words.reduce((sum, w) => sum + w.replace(SPECIAL_CHAR_REGEX, '').length, 0) / words.length
    : 0

  return {
    charCount: text.length,
    wordCount: words.length,
    sentenceCount: sentences.length,
    urlCount: urls.length,
    numberCount: numbers.length,
    uppercaseCount: uppercaseChars,
    specialCharCount: specialChars.length,
    avgWordLength,
  }
}

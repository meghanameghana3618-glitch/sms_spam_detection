/** Binary classification metrics — positive class is "spam". */
export function computeClassificationMetrics(actualLabels, predictions) {
  const n = actualLabels.length
  let tp = 0, tn = 0, fp = 0, fn = 0

  predictions.forEach((pred, i) => {
    const actual = actualLabels[i]
    const predicted = pred.predictedLabel
    if (predicted === 'spam' && actual === 'spam') tp += 1
    else if (predicted === 'ham' && actual === 'ham') tn += 1
    else if (predicted === 'spam' && actual === 'ham') fp += 1
    else fn += 1
  })

  const accuracy = (tp + tn) / n
  const precision = tp + fp > 0 ? tp / (tp + fp) : 0
  const recall = tp + fn > 0 ? tp / (tp + fn) : 0
  const f1 = precision + recall > 0 ? (2 * precision * recall) / (precision + recall) : 0
  const rocAuc = computeRocAuc(actualLabels, predictions.map((p) => p.spamProbability))

  return {
    accuracy, precision, recall, f1, rocAuc,
    confusionMatrix: { tp, tn, fp, fn },
    testSamples: n,
  }
}

/** ROC-AUC via the Mann-Whitney U / rank-sum formula (exact, no threshold sweep). */
function computeRocAuc(actualLabels, scores) {
  const n = actualLabels.length
  const positives = actualLabels.filter((a) => a === 'spam').length
  const negatives = n - positives
  if (positives === 0 || negatives === 0) return null

  const indexed = scores.map((s, i) => ({ s, label: actualLabels[i] === 'spam' ? 1 : 0 }))
  indexed.sort((a, b) => a.s - b.s)

  const ranks = new Array(n)
  let i = 0
  while (i < n) {
    let j = i
    while (j + 1 < n && indexed[j + 1].s === indexed[i].s) j += 1
    const avgRank = (i + j) / 2 + 1
    for (let k = i; k <= j; k++) ranks[k] = avgRank
    i = j + 1
  }

  let rankSumPositive = 0
  indexed.forEach((item, idx) => { if (item.label === 1) rankSumPositive += ranks[idx] })

  return (rankSumPositive - (positives * (positives + 1)) / 2) / (positives * negatives)
}

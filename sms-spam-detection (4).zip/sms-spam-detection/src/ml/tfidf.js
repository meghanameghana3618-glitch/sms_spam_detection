const DEFAULT_MAX_VOCAB = 3000
const DEFAULT_MIN_DOC_FREQ = 2

/**
 * Builds a controlled vocabulary from tokenized training documents: counts
 * document frequency per term, drops rare terms (below minDocFreq), and
 * caps the vocabulary at maxVocab terms (keeping the most common ones) —
 * so the browser never has to build an unnecessarily large matrix.
 */
export function buildVocabulary(tokenizedDocs, { maxVocab = DEFAULT_MAX_VOCAB, minDocFreq = DEFAULT_MIN_DOC_FREQ } = {}) {
  const docFreq = new Map()
  tokenizedDocs.forEach((tokens) => {
    const uniqueTokens = new Set(tokens)
    uniqueTokens.forEach((t) => docFreq.set(t, (docFreq.get(t) || 0) + 1))
  })

  const totalDocs = tokenizedDocs.length
  const kept = [...docFreq.entries()]
    .filter(([, df]) => df >= minDocFreq)
    .sort((a, b) => b[1] - a[1])
    .slice(0, maxVocab)

  const vocabulary = kept.map(([term]) => term)
  const termIndex = new Map(vocabulary.map((term, i) => [term, i]))

  // Smoothed IDF: ln(N / df) + 1, so no term ever gets a zero weight.
  const idf = kept.map(([, df]) => Math.log(totalDocs / df) + 1)

  return {
    vocabulary,
    termIndex,
    idf,
    docFreq: Object.fromEntries(kept),
    totalDocs,
    totalTermsSeen: docFreq.size,
    rareTermsRemoved: docFreq.size - vocabulary.length,
    maxVocab,
    minDocFreq,
  }
}

/** Converts a token list into a dense TF-IDF vector for the given vocabulary. */
export function vectorize(tokens, vocabModel) {
  const { vocabulary, termIndex, idf } = vocabModel
  const vector = new Float32Array(vocabulary.length)
  if (tokens.length === 0) return vector

  const counts = new Map()
  tokens.forEach((t) => {
    const idx = termIndex.get(t)
    if (idx !== undefined) counts.set(idx, (counts.get(idx) || 0) + 1)
  })

  counts.forEach((count, idx) => {
    const tf = count / tokens.length
    vector[idx] = tf * idf[idx]
  })

  return vector
}

import { cleanAndTokenize, trainTestSplit } from './preprocessing'
import { buildVocabulary, vectorize } from './tfidf'
import { trainNaiveBayes } from './naiveBayes'
import { trainLogisticRegression } from './logisticRegression'
import { computeClassificationMetrics } from '../utils/metrics'

/**
 * Full training pipeline: clean + tokenize every message, split 80/20, build
 * the TF-IDF vocabulary from the training set only, vectorize both splits,
 * train Naive Bayes and Logistic Regression, and evaluate each on the same
 * held-out test set.
 */
export function trainModels(messages, { maxVocab = 3000, minDocFreq = 2, epochs = 150, onEpoch } = {}) {
  const tokenizedMessages = messages.map((e) => ({ ...e, tokens: cleanAndTokenize(e.message) }))
  const { trainSet, testSet } = trainTestSplit(tokenizedMessages, 0.2, 42)

  const vocabModel = buildVocabulary(trainSet.map((e) => e.tokens), { maxVocab, minDocFreq })
  const vocabSize = vocabModel.vocabulary.length

  const trainVectors = trainSet.map((e) => vectorize(e.tokens, vocabModel))
  const trainLabels = trainSet.map((e) => e.label)
  const testVectors = testSet.map((e) => vectorize(e.tokens, vocabModel))
  const testLabels = testSet.map((e) => e.label)

  const naiveBayes = trainNaiveBayes(trainVectors, trainLabels, vocabSize)
  const logistic = trainLogisticRegression(trainVectors, trainLabels, vocabSize, { epochs, onEpoch })

  const nbPredictions = testVectors.map((v) => naiveBayes.predictFromVector(v))
  const nbMetrics = computeClassificationMetrics(testLabels, nbPredictions)

  const lrPredictions = testVectors.map((v) => logistic.predictFromVector(v))
  const lrMetrics = computeClassificationMetrics(testLabels, lrPredictions)

  return {
    vocabModel,
    trainSet,
    testSet,
    trainingSamples: trainSet.length,
    testingSamples: testSet.length,
    models: {
      'naive-bayes': { ...naiveBayes, metrics: nbMetrics },
      'logistic-regression': { ...logistic, metrics: lrMetrics },
    },
  }
}

export function vectorizeMessage(message, vocabModel) {
  const tokens = cleanAndTokenize(message)
  return { tokens, vector: vectorize(tokens, vocabModel) }
}

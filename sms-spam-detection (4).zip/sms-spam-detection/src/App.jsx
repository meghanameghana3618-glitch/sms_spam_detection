import React, { useEffect, useState } from 'react'
import Sidebar from './components/Sidebar'
import Header from './components/Header'
import Dashboard from './pages/Dashboard'
import SMSDetector from './pages/SMSDetector'
import MessageAnalysis from './pages/MessageAnalysis'
import ModelPerformance from './pages/ModelPerformance'
import { loadDataset } from './services/dataset'
import { analyzeText } from './utils/textAnalysis'
import { cleanAndTokenize } from './ml/preprocessing'
import { trainModels } from './ml/modelTraining'

const STAGE_LABEL = {
  'loading-data': 'Loading SMS dataset…',
  cleaning: 'Cleaning messages…',
  vocabulary: 'Building vocabulary…',
  tfidf: 'Creating text features…',
  training: 'Training classifier…',
  evaluating: 'Evaluating model…',
}

function engineerMessages(rawMessages) {
  return rawMessages.map((m, i) => {
    const stats = analyzeText(m.message)
    const tokens = cleanAndTokenize(m.message)
    const termFrequency = new Map()
    tokens.forEach((t) => termFrequency.set(t, (termFrequency.get(t) || 0) + 1))
    return { id: i + 1, label: m.label, message: m.message, tokens, termFrequency, ...stats }
  })
}

export default function App() {
  const [page, setPage] = useState('dashboard')
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const [rawMessages, setRawMessages] = useState(null)
  const [engineeredMessages, setEngineeredMessages] = useState(null)
  const [trainingResult, setTrainingResult] = useState(null)
  const [stage, setStage] = useState('loading-data')
  const [error, setError] = useState(null)
  const [modelKey, setModelKey] = useState('naive-bayes')
  const [epochProgress, setEpochProgress] = useState({ epoch: 0, total: 150 })

  useEffect(() => {
    let cancelled = false
    async function run() {
      try {
        const messages = await loadDataset()
        if (cancelled) return
        setRawMessages(messages)
        setStage('cleaning')

        const engineered = engineerMessages(messages)
        if (cancelled) return
        setEngineeredMessages(engineered)

        await new Promise((r) => setTimeout(r, 150))
        if (cancelled) return
        setStage('vocabulary')

        await new Promise((r) => setTimeout(r, 120))
        if (cancelled) return
        setStage('tfidf')

        await new Promise((r) => setTimeout(r, 120))
        if (cancelled) return
        setStage('training')

        const result = trainModels(messages, {
          maxVocab: 3000,
          minDocFreq: 2,
          epochs: 150,
          onEpoch: (epoch, total) => { if (!cancelled) setEpochProgress({ epoch, total }) },
        })
        if (cancelled) return
        setStage('evaluating')

        await new Promise((r) => setTimeout(r, 120))
        if (cancelled) return
        setTrainingResult(result)
        setStage('ready')
      } catch (err) {
        if (!cancelled) {
          setError(err.message || 'Something went wrong loading the app.')
          setStage('error')
        }
      }
    }
    run()
    return () => { cancelled = true }
  }, [])

  const status = stage === 'ready' ? 'ready' : stage === 'error' ? 'error' : 'loading'
  const modelLabel = trainingResult ? trainingResult.models[modelKey].label : (modelKey === 'naive-bayes' ? 'Naive Bayes' : 'Logistic Regression')

  if (stage !== 'ready' && stage !== 'error') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-paper px-6">
        <div className="text-center max-w-sm">
          <p className="font-display text-2xl text-ink mb-2">SMS Spam Detection</p>
          <p className="text-sm text-ink/50 mb-6">{STAGE_LABEL[stage]}</p>
          <div className="w-full h-1.5 bg-black/10 rounded-full overflow-hidden mb-2">
            <div
              className="h-full bg-teal4 transition-all duration-150"
              style={{ width: stage === 'training' ? `${(epochProgress.epoch / epochProgress.total) * 100}%` : '45%' }}
            />
          </div>
          {stage === 'training' && <p className="text-xs text-ink/40">Epoch {epochProgress.epoch} / {epochProgress.total}</p>}
        </div>
      </div>
    )
  }

  if (stage === 'error') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-paper px-6">
        <div className="text-center max-w-sm bg-white border border-black/5 rounded-lg p-6">
          <p className="font-display text-xl text-ink mb-2">Couldn't start the app</p>
          <p className="text-sm text-ink/60">{error}</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen md:flex">
      <Sidebar activePage={page} onNavigate={setPage} open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="flex-1 min-w-0">
        <Header activePage={page} onMenuClick={() => setSidebarOpen(true)} status={status} model={modelLabel} />
        <main className="p-4 md:p-8 min-w-0">
          {page === 'dashboard' && <Dashboard engineeredMessages={engineeredMessages} trainingResult={trainingResult} />}
          {page === 'detector' && (
            <SMSDetector
              engineeredMessages={engineeredMessages}
              trainingResult={trainingResult}
              modelKey={modelKey}
              onModelChange={setModelKey}
              status={status}
            />
          )}
          {page === 'analysis' && <MessageAnalysis engineeredMessages={engineeredMessages} trainingResult={trainingResult} />}
          {page === 'performance' && (
            <ModelPerformance trainingResult={trainingResult} modelKey={modelKey} onModelChange={setModelKey} />
          )}
        </main>
      </div>
    </div>
  )
}

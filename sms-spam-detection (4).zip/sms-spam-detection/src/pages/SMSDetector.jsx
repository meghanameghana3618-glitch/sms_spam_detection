import React, { useRef, useState } from 'react'
import SMSInput from '../components/SMSInput'
import PredictionResult from '../components/PredictionResult'
import ReportButton from '../components/ReportButton'
import { analyzeText } from '../utils/textAnalysis'
import { vectorizeMessage } from '../ml/modelTraining'
import { modelTopTerms } from '../utils/vocabulary'
import { computeSummary } from '../services/dataset'
import { generateDatasetInsights, generateModelInsight } from '../utils/insights'

export default function SMSDetector({ engineeredMessages, trainingResult, modelKey, onModelChange, status }) {
  const [result, setResult] = useState(null)
  const [threshold, setThreshold] = useState(0.5)
  const [formError, setFormError] = useState(null)
  const resultRef = useRef(null)

  const ready = status === 'ready' && trainingResult

  const handleSubmit = (rawText) => {
    if (!ready) return
    if (!rawText || !rawText.trim()) {
      setFormError('Please enter an SMS message.')
      setResult(null)
      return
    }
    setFormError(null)
    setThreshold(0.5)

    const model = trainingResult.models[modelKey]
    const { tokens, vector } = vectorizeMessage(rawText, trainingResult.vocabModel)
    const prediction = model.predictFromVector(vector)
    const textStats = analyzeText(rawText)

    const { spamTerms, hamTerms } = modelTopTerms(model, trainingResult.vocabModel, 25)
    const relevantTerms = new Set([...spamTerms, ...hamTerms].map((t) => t.term))
    const matchedTerms = [...new Set(tokens)].filter((t) => relevantTerms.has(t)).slice(0, 10)

    setResult({
      ...prediction,
      modelLabel: model.label,
      textStats,
      matchedTerms,
    })
  }

  const summary = computeSummary(engineeredMessages)
  const insights = [...generateDatasetInsights(engineeredMessages, summary, trainingResult?.vocabModel)]
  const modelInsight = trainingResult ? generateModelInsight(trainingResult.models) : null
  if (modelInsight) insights.push(modelInsight)

  const reportPrediction = result ? { ...result, predictedLabel: result.spamProbability >= threshold ? 'spam' : 'ham' } : null

  return (
    <div className="space-y-6">
      <div className="grid lg:grid-cols-2 gap-6">
        <SMSInput modelKey={modelKey} onModelChange={onModelChange} onSubmit={handleSubmit} modelReady={ready} error={formError} />
        <PredictionResult result={result} threshold={threshold} onThresholdChange={setThreshold} innerRef={resultRef} />
      </div>

      {result && (
        <div className="flex justify-end">
          <ReportButton
            summary={summary}
            trainingResult={trainingResult}
            modelKey={modelKey}
            prediction={reportPrediction}
            insights={insights}
            chartElement={resultRef.current}
          />
        </div>
      )}
    </div>
  )
}

import React, { useMemo, useState } from 'react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import StatCard from '../components/StatCard'
import ChartCard from '../components/ChartCard'
import SMSTable from '../components/SMSTable'
import SMSDetails from '../components/SMSDetails'
import { computeSummary } from '../services/dataset'
import { wordFrequencyByClass, topWordsFromFrequency } from '../utils/vocabulary'

const avg = (arr) => arr.reduce((a, b) => a + b, 0) / arr.length

function histogram(values, buckets = 6) {
  const min = Math.min(...values)
  const max = Math.max(...values)
  const width = (max - min) / buckets || 1
  const bins = Array.from({ length: buckets }, (_, i) => ({
    range: `${Math.round(min + i * width)}-${Math.round(min + (i + 1) * width)}`,
    count: 0,
  }))
  values.forEach((v) => {
    let idx = Math.floor((v - min) / width)
    if (idx >= buckets) idx = buckets - 1
    if (idx < 0) idx = 0
    bins[idx].count += 1
  })
  return bins
}

export default function MessageAnalysis({ engineeredMessages, trainingResult }) {
  const [selected, setSelected] = useState(null)
  const summary = computeSummary(engineeredMessages)

  const spam = engineeredMessages.filter((e) => e.label === 'spam')
  const ham = engineeredMessages.filter((e) => e.label === 'ham')

  const wordCountDist = useMemo(() => histogram(engineeredMessages.map((e) => e.wordCount)), [engineeredMessages])

  const avgLengthByClass = [
    { label: 'Spam', avgLength: Math.round(avg(spam.map((e) => e.charCount))) },
    { label: 'Normal', avgLength: Math.round(avg(ham.map((e) => e.charCount))) },
  ]

  const freqByClass = useMemo(() => wordFrequencyByClass(engineeredMessages), [engineeredMessages])
  const topSpamWords = useMemo(() => topWordsFromFrequency(freqByClass.spam, 10), [freqByClass])
  const topHamWords = useMemo(() => topWordsFromFrequency(freqByClass.ham, 10), [freqByClass])

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard label="Total Messages" value={summary.totalMessages} />
        <StatCard label="Spam Messages" value={summary.spamCount} />
        <StatCard label="Normal Messages" value={summary.normalCount} />
        <StatCard label="Spam Percentage" value={`${summary.spamPercentage.toFixed(1)}%`} />
        <StatCard label="Average Message Length" value={`${summary.averageLength.toFixed(0)} chars`} />
        <StatCard label="Average Word Count" value={avg(engineeredMessages.map((e) => e.wordCount)).toFixed(1)} />
        <StatCard label="Vocabulary Size" value={trainingResult ? trainingResult.vocabModel.vocabulary.length : '—'} />
        <StatCard label="Avg Spam Word Count" value={avg(spam.map((e) => e.wordCount)).toFixed(1)} />
      </div>

      <div className="grid md:grid-cols-2 gap-5">
        <ChartCard title="Word Count Distribution">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={wordCountDist} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e9eaec" vertical={false} />
              <XAxis dataKey="range" tick={{ fontSize: 9 }} interval={0} angle={-20} textAnchor="end" height={50} />
              <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="count" fill="#4A5FB0" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Average Length by Class">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={avgLengthByClass} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e9eaec" vertical={false} />
              <XAxis dataKey="label" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Bar dataKey="avgLength" fill="#B8543F" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Most Common Spam Terms">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={topSpamWords} layout="vertical" margin={{ top: 10, right: 20, bottom: 0, left: 10 }}>
              <CartesianGrid stroke="#e9eaec" horizontal={false} />
              <XAxis type="number" tick={{ fontSize: 11 }} allowDecimals={false} />
              <YAxis type="category" dataKey="term" tick={{ fontSize: 10 }} width={80} />
              <Tooltip />
              <Bar dataKey="count" fill="#B8543F" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Most Common Normal Terms">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={topHamWords} layout="vertical" margin={{ top: 10, right: 20, bottom: 0, left: 10 }}>
              <CartesianGrid stroke="#e9eaec" horizontal={false} />
              <XAxis type="number" tick={{ fontSize: 11 }} allowDecimals={false} />
              <YAxis type="category" dataKey="term" tick={{ fontSize: 10 }} width={80} />
              <Tooltip />
              <Bar dataKey="count" fill="#2C7C7A" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <p className="text-xs text-ink/40 px-1">
        Word frequency reflects patterns in this dataset only — individual words are not treated as
        definitive spam evidence; the model's classification always considers the full message.
      </p>

      <div className="grid lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2 min-w-0">
          <SMSTable messages={engineeredMessages} onSelect={setSelected} selectedId={selected?.id} />
        </div>
        <SMSDetails message={selected} />
      </div>
    </div>
  )
}

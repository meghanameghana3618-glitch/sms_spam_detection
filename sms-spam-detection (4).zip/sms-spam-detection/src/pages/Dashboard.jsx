import React, { useMemo } from 'react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, PieChart, Pie } from 'recharts'
import StatCard from '../components/StatCard'
import ChartCard from '../components/ChartCard'
import { computeSummary } from '../services/dataset'
import { generateDatasetInsights } from '../utils/insights'
import { wordFrequencyByClass, topWordsFromFrequency } from '../utils/vocabulary'

function histogram(values, buckets = 6) {
  const min = Math.min(...values)
  const max = Math.max(...values)
  const width = (max - min) / buckets || 1
  const bins = Array.from({ length: buckets }, (_, i) => ({
    range: `${Math.round(min + i * width)}-${Math.round(min + (i + 1) * width)}`,
    count: 0,
  }))
  values.forEach((v) => {
    let idx = Math.floor((v - min) / width)
    if (idx >= buckets) idx = buckets - 1
    if (idx < 0) idx = 0
    bins[idx].count += 1
  })
  return bins
}

export default function Dashboard({ engineeredMessages, trainingResult }) {
  const summary = computeSummary(engineeredMessages)
  const insights = useMemo(() => generateDatasetInsights(engineeredMessages, summary, trainingResult?.vocabModel), [engineeredMessages])

  const distribution = [
    { name: 'Spam', value: summary.spamCount },
    { name: 'Normal', value: summary.normalCount },
  ]

  const lengthDist = useMemo(() => histogram(engineeredMessages.map((e) => e.charCount)), [engineeredMessages])

  const avgLengthByClass = useMemo(() => {
    const avg = (arr) => arr.reduce((a, b) => a + b, 0) / arr.length
    const spam = engineeredMessages.filter((e) => e.label === 'spam').map((e) => e.charCount)
    const ham = engineeredMessages.filter((e) => e.label === 'ham').map((e) => e.charCount)
    return [
      { label: 'Spam', avgLength: Math.round(avg(spam)) },
      { label: 'Normal', avgLength: Math.round(avg(ham)) },
    ]
  }, [engineeredMessages])

  const freqByClass = useMemo(() => wordFrequencyByClass(engineeredMessages), [engineeredMessages])
  const topSpamWords = useMemo(() => topWordsFromFrequency(freqByClass.spam, 8), [freqByClass])
  const topHamWords = useMemo(() => topWordsFromFrequency(freqByClass.ham, 8), [freqByClass])

  const COLORS = ['#B8543F', '#2C7C7A']

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
        <StatCard label="Total Messages" value={summary.totalMessages} />
        <StatCard label="Spam Messages" value={summary.spamCount} />
        <StatCard label="Normal Messages" value={summary.normalCount} />
        <StatCard label="Spam Percentage" value={`${summary.spamPercentage.toFixed(1)}%`} />
        <StatCard label="Average Message Length" value={`${summary.averageLength.toFixed(0)} chars`} />
        <StatCard label="Vocabulary Size" value={trainingResult ? trainingResult.vocabModel.vocabulary.length : '—'} />
      </div>

      {insights.length > 0 && (
        <div className="bg-white rounded-lg border border-black/5 px-5 py-3 space-y-1">
          {insights.slice(0, 2).map((text, i) => <p key={i} className="text-sm text-ink/70">{text}</p>)}
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-5">
        <ChartCard title="Spam vs Normal Distribution">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={distribution} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                {distribution.map((d, i) => <Cell key={i} fill={COLORS[i]} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Message Length Distribution">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={lengthDist} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e9eaec" vertical={false} />
              <XAxis dataKey="range" tick={{ fontSize: 9 }} interval={0} angle={-20} textAnchor="end" height={50} />
              <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="count" fill="#4A5FB0" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Average Message Length by Class">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={avgLengthByClass} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e9eaec" vertical={false} />
              <XAxis dataKey="label" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Bar dataKey="avgLength" radius={[4, 4, 0, 0]}>
                <Cell fill="#B8543F" />
                <Cell fill="#2C7C7A" />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Top Spam Words">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={topSpamWords} layout="vertical" margin={{ top: 10, right: 20, bottom: 0, left: 10 }}>
              <CartesianGrid stroke="#e9eaec" horizontal={false} />
              <XAxis type="number" tick={{ fontSize: 11 }} allowDecimals={false} />
              <YAxis type="category" dataKey="term" tick={{ fontSize: 10 }} width={80} />
              <Tooltip />
              <Bar dataKey="count" fill="#B8543F" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Top Normal Words" className="md:col-span-2">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={topHamWords} layout="vertical" margin={{ top: 10, right: 20, bottom: 0, left: 10 }}>
              <CartesianGrid stroke="#e9eaec" horizontal={false} />
              <XAxis type="number" tick={{ fontSize: 11 }} allowDecimals={false} />
              <YAxis type="category" dataKey="term" tick={{ fontSize: 10 }} width={80} />
              <Tooltip />
              <Bar dataKey="count" fill="#2C7C7A" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </div>
  )
}
